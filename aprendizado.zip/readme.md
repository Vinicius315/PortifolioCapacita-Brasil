# Projeto-Final-Capacita-Brasil


## Índice
- [O Projeto](#the-project)
- [Membros](#membros)
- [Imagens](#screenshot)
- [Links](#links)
- [Tecnologia](#tecnologias-e-recursos)

## O Projeto

Projeto final da primeira etapa do módulo full-stack do bootcamp Atlântico Avanti. Um site de portfólio contendo projetos e atuação como desenvolvedor full-stack.

### Membros
- [Karol Rodrigues](https://github.com/Karol-Rodrigues00)
- [Jullyan Gomes](https://github.com/jullyanvpr)
- [Lucas Viana](https://github.com/Lucas190118)
- [Romulo](https://github.com/kaishiix)
- [Vinícius Noronha](https://github.com/Vinicius315)

### Links

- Site URL: [Link ativo]()


### Screenshots

![screenshot]()
![screenshot]()
![screenshot]()
![screenshot]()



### Tecnologias e Recursos

- HTML5 semântico
- Flexbox e Grid
- Desktop-first workflow
- Formulários com validação

